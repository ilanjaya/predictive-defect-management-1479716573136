f_library = function()
  {
    
    require(mongolite)
    require(reshape2)
    require(plyr)
    require(dplyr)
    require(car)
    require(lubridate)
    require(data.table)  
    require(stats)
    
    return("Info: Libraries loaded")
 }