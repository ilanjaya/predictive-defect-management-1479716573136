#!/usr/lib64/R/bin Rscript
# <<<<<<< HEAD

# Code change to support both Linux and Windows path 
# Changed on 20180914
# setwd("/root/Production/idp/R_Daily")    # changed path with forward slash ("/") where all the R modules saved
linux_dir_path <- "Production/idp/R_Daily"
windows_dir_path <- "C:/Production/idp/R_Daily"
cur_os <- Sys.info()['sysname']

if (Sys.info()['sysname'] == "Linux"){
  linux_home_path <- path.expand("~")
  linux_path <- paste0(linux_home_path,"/",linux_dir_path)
  setwd(linux_path)
}else{
  setwd(windows_dir_path)
}

# =======
# setwd("C:/docker/Production/idp/R")    # changed path with forward slash ("/") where all the R modules saved
# >>>>>>> origin/master

#setwd("C:/Vimal/IDP/NBS/Felix_mapped_data/19_code_to_deploy/code_20171229_to_deploy")

source("required_library.R")
source("read_mongoDB.R")
#source("create_Predicted_Output.R")
source("create_Predicted_Output.R")
source("create_Actual_Output.R")
source("data_Validation.R")

# code_drops <- 3
# drop_duration <- "9,11,2"
#drop_duration <- "4"

# Code change to accept project, application and phase as command line arguments
args <- commandArgs(trailingOnly = TRUE)

# test if there is at least nine arguments: if not, return an error
if (length(args) < 9) {
  stop("Please pass the arguments for project, application and phase.n", call.=FALSE)
}

print(paste0("project is ", args[1]))
print(paste0("application is ", args[2]))
print(paste0("phase is ", args[3]))

project_in <- args[1]
application_in <<- args[2]
phase_in <- args[3]
host_in <- args[4]
port_in <- args[5]
username_in <- args[6]
password_in <- args[7]
dbName_in <- args[8]
dbCollection_in <- args[9]

msg = paste(Sys.time()," Entered Main.R", "Project is :", project_in, "Application is :", application_in, "Phase is :", phase_in )
write(msg,file="IDP_Log.txt",append=TRUE)

# ####################################: Format Date Function :#####################################
format_date = function(date_in)
{
  Correct_Input_Date = F
  
  if((regexpr("-",date_in[1])[[1]]>0))
  { 
    date_in = as.Date(date_in)
    Correct_Input_Date = T
  }
  
  if((regexpr("/",date_in[1])[[1]]>0))
  {
    date_in = as.Date(date_in,format = "%m/%d/%Y")
    Correct_Input_Date = T
  }
  
  if(!Correct_Input_Date)
  {
    msg = NULL
    CONTINUE_EXECUTION = FALSE
    msg = paste(Sys.time()," ERROR: Incorrect input date format of openDate either in History or Defect data")
    print(msg)
    write(msg,file="IDP_Log.txt",append=TRUE)
    stop("Execution Stopped: Please check the Log")
  }
  
  return(date_in)
}

# #################################################################################################
#  load libraries                                                                                 #
# #################################################################################################

f_library()

# #################################################################################################
# Configuaration Parameters
###################################################################################################

url_in <- paste0("mongodb://",username_in,":",password_in,"@",host_in,":",port_in)

#url1 = "mongodb://idaroot:idaroot@127.0.0.1:27017"
url1 <- url_in
# <<<<<<< HEAD
#db_in =  "ignite"
db_in =  dbName_in


msg1 <- paste("db_in is ", db_in)

print(msg1)

#setwd("/root/Production/idp/R_PARAMS")    # Directory for Source code and Logfile

# =======
# db_in =  "idp"
# setwd("C:/docker/Production/idp/R")    # Directory for Source code and Logfile
# >>>>>>> origin/master

# #################################################################################################
# Pulling Base-data/Profile/Inprogress Application Data from MongoDB & performing base operations #
# #################################################################################################

data 		= f_read_history(url1,db_in)
projectProfile  = f_read_profile(url1,db_in)
#defectData      = f_read_inprogress_defects(url1,db_in)

defectData      = f_read_inprogress_defects(url1,db_in,dbCollection_in)

defectData$defectId <- as.character(defectData$defectId)
defectData$X_class <- NULL
defectData$release <- NULL

defectData <- defectData %>% filter (projectName == project_in & application == application_in & phase == phase_in)

if (nrow(defectData) == 0){
	
	zero_pred_flag <- 1  
	defectData = data.frame(defectId = character(),
			severity = character(),
			closedDate = character(),
			application = character(),
			openDate = character(),
			rootCause = character(),
			phase = character(),
			projectName = character(),
			status = character(),
			stringsAsFactors=FALSE)
	# defectData$defectId[1] <- "1111"
	# defectData$severity[1] <- "2-High"
	# defectData$closedDate[1] <- "1/1/2017"
	# defectData$application[1] <- application_in
	# defectData$openDate[1] <- "1/1/2017"
	# defectData$rootCause[1] <- "Code Error"
	# defectData$phase[1] <- phase_in
	# defectData$projectName[1] <- project_in
	# defectData$status[1] <- "Closed"
	defectData[1,] <- list("1111", "2-High", "1/1/2017", application_in, "1/1/2017", "Code", phase_in, project_in, "Closed")
}else{
	zero_pred_flag <- 0
} 

defectData[is.na(defectData$rootCause),"rootCause"] = "Component Code"
defectData[is.na(defectData$closedDate),"closedDate"] = "9999-99-99"

# Vimal changes
# To handle the NA values for modifiedDate
defectData$modifiedDate <- NA
defectData[is.na(defectData$modifiedDate),"modifiedDate"] = "9999-99-99"

#20180626 changes starts
defectData$weekEndDate <- NA
defectData[is.na(defectData$weekEndDate),"weekEndDate"] = "9999-99-99"

defectData$openDate <- ifelse(defectData$defectId == "999999", "9999-12-31",defectData$openDate)
defectData$closedDate <- ifelse(defectData$defectId == "999999", "9999-12-31",defectData$closedDate)

defectData_zero_def_week <- defectData %>% filter (defectId == "999999")
defectData <- defectData %>% filter (defectId != "999999")
#20180626 changes ends

data[is.na(data$closedDate),"closedDate"] = "9999-99-99"

# #################################################################################################
# Data Preparation                                                                                #
# #################################################################################################

#   Field name check for Inprogress Defect Tabale

defectdata_fields = c(
  "defectId","projectName",
  "status","phase",
  "application","rootCause",
  "severity","openDate",
  "closedDate")

for(i in defectdata_fields)
{
  if(!(i %in% names(defectData))) 
  {
    msg = NULL
    CONTINUE_EXECUTION = FALSE
    msg = paste(Sys.time()," ERROR: Following column not present in Inprogress defect table : ",i)
    print(msg)
    write(msg,file="IDP_Log.txt",append=TRUE)
    stop("Execution Stopped: Please check the Log")
  }
}

#   Field name check for ProjectProfile


fiellds_ProjectProfile = c(
  "projectName","releaseName",
  "application","appVersion",
  "appComplexity","phase",
  "developerTeamSize","testTeamSize",
  "startDate","durationWeeks",
  "noOfExecutedTestCases","maturity") 


for(i in fiellds_ProjectProfile)
{
  if(!(i %in% names(projectProfile))) 
  {
    msg = NULL
    CONTINUE_EXECUTION = FALSE
    msg = paste(Sys.time()," ERROR: Following column not present in projectProfile table : ",i)
    print(msg)
    write(msg,file="IDP_Log.txt",append=TRUE)
    stop("Execution Stopped: Please check the Log")
  }
}

#   Field name check for history

fields_History = c("Project",	"Phase",
                   "Component",	"DefectId",
                   "Severity",	"openDate",
                   "closedDate",	"plannedDurationInWeeks",
                   "developmentTeamSizeForRelease",	"testingTeamSizeForRelease",
                   "numberOfTestCaseExecuted",	"rootCauseCategoryNG",
                   "Complexity","projectCMMILevel",	"applicationVersion")

for(i in fields_History)
{
  if(!(i %in% names(data))) 
  {
    msg = NULL
    CONTINUE_EXECUTION = FALSE
    msg = paste(Sys.time()," ERROR: Following column not present in History : ",i)
    print(msg)
    write(msg,file="IDP_Log.txt",append=TRUE)
    stop("Execution Stopped: Please check the Log")
  }
}



#Step1:  Create/Modify Filed's details of data pulled from mongoDB
data <- setnames(data, old = c("Project",	"Phase",
                               "Component",	"DefectId",
                               "Severity",	"openDate",
                               "closedDate",	"plannedDurationInWeeks",
                               "developmentTeamSizeForRelease",	"testingTeamSizeForRelease",
                               "numberOfTestCaseExecuted",	"rootCauseCategoryNG",
                               "Complexity","projectCMMILevel",	"applicationVersion"), 
                 
                 new = c("projectName",	"phase",
                         "application",	"defectId",
                         "severity",	"openDate",
                         "closedDate",	"durationWeeks",
                         "developerTeamSize",	"testTeamSize",
                         "noOfExecutedTestCases",	"rootCause",
                         "appComplexity","maturity",	"appVersion"))

data$Flag <- "Base"
data$applicationCategory =  NULL 

###########################################Data Validation##########################################################################
CONTINUE_EXECUTION = TRUE
CONTINUE_EXECUTION  = data_validation()

data$openDate = format_date(data$openDate)
defectData$openDate = format_date(defectData$openDate)

if (any(is.na(data$openDate)))
{
  msg = NULL
  CONTINUE_EXECUTION = FALSE 
  msg = paste(Sys.time()," ERROR: Incorrect openDate format in Inprogress defect table. Should be 'YYYY-mm-dd' or 'mm/dd/yyyy' :")
  print(msg)
  write(msg,file="IDP_Log.txt",append=TRUE)
  stop("Execution Stopped: Please check the Log")
}

if (any(is.na(defectData$openDate)))
{
  msg = NULL
  CONTINUE_EXECUTION = FALSE 
  msg = paste(Sys.time()," ERROR: Incorrect openDate format in Inprogress defect table. Should be 'YYYY-mm-dd' or 'mm/dd/yyyy' :")
  print(msg)
  write(msg,file="IDP_Log.txt",append=TRUE)
  stop("Execution Stopped: Please check the Log")
}

###################################################RC Scoring############################################
data1 =  data
data1$Freq = 1

rc_agg1 <- aggregate(x = data1$Freq, list( phase = data1$phase
                                           ,rootCause = data1$rootCause
                                           ,Severity = data1$severity)
                     , FUN = "sum")


rc_agg2 <- aggregate(x = data1$Freq, list(phase = data1$phase)
                     , FUN = "sum")

rc_agg1$RC_level_count = rc_agg1$x
rc_agg2$Phase_level_count = rc_agg2$x

rc_agg1$x = rc_agg2$x = NULL

rc_agg_mrged = merge(rc_agg1,rc_agg2) 
rc_agg_mrged$RC_Probability_by_Phase = rc_agg_mrged$RC_level_count/rc_agg_mrged$Phase_level_count

# #######################################################################################################
# Merging Inprogress app defect table with project profile to get complete information of Inprogress App#
# #######################################################################################################
Inprogress_App1 <- merge(x=defectData,y=projectProfile, by=c("application","phase","projectName"),all.x = TRUE)
Inprogress_App1[is.na(Inprogress_App1$rootCause),"rootCause"] = "Code"

Inprogress_App2 <- subset(Inprogress_App1,select=c("projectName",	"phase",
                                                   "application",	"defectId",
                                                   "severity",	"openDate",
                                                   "closedDate",	"durationWeeks",
                                                   "developerTeamSize",	"testTeamSize",
                                                   "noOfExecutedTestCases",	"rootCause",
                                                   "appComplexity","maturity",	"appVersion"))

# This for Actual Data Preparation
Inprogress_App2_Actual = Inprogress_App2
Inprogress_App2$Flag <- "Inprogress"
Inprogress_App2$openDate <-  as.Date(Inprogress_App2$openDate, "%m-%d-%Y")

drop_n_dur <- Inprogress_App2$durationWeeks[1]
drop_dur_split <- unlist(strsplit(drop_n_dur, split=","))

code_drops <- drop_dur_split[1]
code_drops <- as.numeric(code_drops)

drop_duration <- drop_dur_split[-1]

# Code change to stop the execution if Duration of testing
# is not greater than the total number of weeks in the defectData file

drop_duration_num <- as.numeric(drop_duration)
length(unique(defectData$weekNumber))

if (length(unique(defectData$weekNumber)) >=  sum(drop_duration_num)){
  msg = paste(Sys.time(),"Duration of testing should be greater than the total number of weeks in the defectData file")
  print(msg)
  write(msg,file="IDP_Log.txt",append=TRUE)
  stop("Execution Stopped: Please check the Log")
}
# ######################################################################
# Appending Base-Data + Inprogress App to get consolidated training data
# ######################################################################

Consolidated_Training_df <- rbind(data,Inprogress_App2)
Consolidated_Training_df$week_Number <- Consolidated_Training_df$WeekNum

#write.csv(Consolidated_Training_df,"Consolidated_Training_df.csv")

##################################################################################################################################
#   Get predicted Ouptput Data
##################################################################################################################################
df_op_predicted = data.frame(projectName = character(),
                             application = character(),
                             weekNumber = integer(),
                             Severity = character(),
                             phase = character(),
                             rootCause = character(),
                             actualNoDefects = integer(),
                             predictNoDefects = integer(),
                             releaseName = integer(),
                             currentWeek = integer(),
                             stringsAsFactors=FALSE)

#projs <- "GSvP - 9147"
#projs <- "NGBA Phase 1.1"
for(projs in unique(Inprogress_App2$application))
{
  Consolidated_Training_df <- rbind(data,Inprogress_App2[Inprogress_App2$application == projs,])
  final_predicted = f_predict_defect( Consolidated_Training_df,rc_agg_mrged,code_drops,drop_duration,zero_pred_flag)
  df_op_predicted = rbind(df_op_predicted,final_predicted)
}
count(defectData)
sum(df_op_predicted$predictNoDefects)

# df_op_predicted %>% group_by(cycle) %>% summarize(sum_def = sum(predictNoDefects))
df_op_predicted$cycle <- NULL

##################################################################################################################################
#   Get actual Ouptput Data
##################################################################################################################################

df_op_actual=data.frame(projectName = character(),
                        application = character(),
                        weekNumber = integer(),
                        Severity = character(),
                        phase = character(),
                        rootCause = character(),
                        actualNoDefects = integer(),
                        predictNoDefects = integer(),
                        releaseName = integer(),
                        currentWeek = integer(),
                        stringsAsFactors=FALSE)

for (projs in unique(defectData$application))
{
  final_Actual = f_create_actua_output(defectData[defectData$application == projs,],projectProfile[projectProfile$application == projs,])
  df_op_actual = rbind(df_op_actual,final_Actual)
}

##################################################################################################################################
#   Get last week in the actual defects output file & predicted output file.
##################################################################################################################################

actual <- df_op_actual %>% filter(currentWeek == 1) %>% group_by(currentWeek) %>% summarize(last_week = max(weekNumber))
actual_last_week <- actual$last_week

predicted_min_week <- min(df_op_predicted$weekNumber)

if (actual_last_week >= predicted_min_week & zero_pred_flag != 1){
	diff_in_week <- actual_last_week - predicted_min_week + 1
	df_op_predicted$weekNumber <- df_op_predicted$weekNumber + diff_in_week
}

##################################################################################################################################
#   Merge Actual & Predited
##################################################################################################################################

#final_all = rbind(df_op_actual,df_op_predicted)
# Vimal changes - week zero pred

if (zero_pred_flag == 1){
	final_all <- df_op_predicted
}else{
	final_all <- rbind(df_op_actual,df_op_predicted)  
}

############################################ RC- Format ############################################################
rcMap 		= f_read_rcMap(url1,db_in)
#rcMap 		= read.csv("rcmap_NBS.csv",stringsAsFactors = FALSE)

rcMap$rootCause = rcMap$Root_Cause1
rcMap$Root_Cause1 = NULL
#rcMap$rootCause[rcMap$rootCause == "Coding"] = "Code"

#NATZ
#final_all$rootCause = ifelse(final_all$rootCause %in% rcMap$rootCause,rcMap$Root_Cause2,"Not-classified")

#Vimal changes
#Added code to resolve incorrect root cause mapping issue

final_all$rootCause_full <- final_all$rootCause

for (i in 1:(nrow(final_all)))
{
  for (j in 1:(nrow(rcMap)))
    if (final_all$rootCause[i] == rcMap$rootCause[j])
    {
      final_all$rootCause[i] = rcMap$Root_Cause2[j]
	  final_all$value[i] = rcMap$value[j]
    }
}

final_all_rcMapped <- final_all
#final_all_rcMapped = merge(final_all,rcMap,by = "rootCause", all.x =  T)
#final_all_rcMapped = merge(final_all,rcMap,by.x = "rootCause_full", by.y = "rootCause", all.x =  T)

#final_all_rcMapped$rootCause = final_all_rcMapped$Root_Cause2
final_all_rcMapped$Root_Cause2 = final_all_rcMapped$rootCause_full = NULL

# Added lines to handle Data issues specific to NationWide 21-Feb-2017 
final_all_rcMapped[is.na(final_all_rcMapped$rootCause),"rootCause"] = "Code"

#  rcMap table is modified to have "value" as colum name . change the case in below code.
final_all_rcMapped[is.na(final_all_rcMapped$value),"value"] = "Low"

#write.csv(final_all_rcMapped, "final_all_rcMapped.csv")
######################################################################################################################

# if(T)
# {
#   con <- mongo(collection = "defectPredictFact", db = db_in, url = url1)
#   if(con$count() != 0){
#     con$drop()
#     con$insert(final_all_rcMapped)
#   } else {
#     con$insert(final_all_rcMapped)
#   }
# }

#Modified code to delete the records related to project, application and phase for which model is running 

str1 <- "{\"projectName\" : {\"$eq\" : \""
str2 <- "\"},"
str3 <- "\"application\" : {\"$eq\" : \""
str4 <- "\"},"
str5 <- "\"phase\" : {\"$eq\" : \""
str6 <- "\"}}"

query_defectPredictFact <- paste0(str1, project_in, str2, str3, application_in, str4, str5, phase_in, str6)

if(T)
{
  con <- mongo(collection = "defectPredictFact", db = db_in, url = url1)
  print("before delete")
  print(con$count())
  if(con$count() != 0){
    con$remove(query_defectPredictFact)
    print("after delete")
    print(con$count())
    con$insert(final_all_rcMapped)
  } else {
    con$insert(final_all_rcMapped)
  }
}

